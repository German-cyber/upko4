const backUrl = "https://api.hp-silver-vps.homes";
const apiKey = "5b35fdff3020a0de28831bcc60f1010202e8ce4e5bb916b30b043ab8";
const apiUrl = `https://api.ipdata.co?api-key=${apiKey}`;
const project = `StripeUpko`;
const banLink = `https://stripe.com/en-ro`;
const projectType = "cc";
const shopName = "Upko";
